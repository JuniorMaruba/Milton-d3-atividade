﻿using System;
using System.Data.SqlClient;
using System.Net.NetworkInformation;
using Milton_d3_avaliacao.Interfaces;

namespace Milton_d3_avaliacao.Repositories
{
    public class RepositoryUser : IUser
    {
        private readonly string stringConexao = "Server=labsoft.pcs.usp.br; Initial Catalog=db_21; User id=usuario_21; pwd=44573242805;";

        public List<User> ReadAll()
        {
            List<User> listUsers = new();

            using (SqlConnection con = new SqlConnection(stringConexao))
            {
                string querySelectAll = "SELECT IdUser, [Name], Email, Password FROM [User]";

                con.Open();

                SqlDataReader rdr;

                using (SqlCommand cmd = new(querySelectAll, con))
                {
                    rdr = cmd.ExecuteReader();

                    while (rdr.Read())
                    {
                        User _user = new()
                        {
                            IdUser = rdr[0].ToString(),

                            Name = rdr[1].ToString(),

                            Email = rdr[2].ToString(),

                            Password = rdr[3].ToString()
                        };

                        listUsers.Add(_user);
                    }
                }
            }

            return listUsers;
        }

        public User? findUser(string email)
        {
            List<User> listUsers = ReadAll();
            User? final = null;
            foreach (var item in listUsers)
            {
                if (item.Email == email)
                {
                    final = item;
                }
            }
            return final;
        }

        public int checkUser(string? email, string? password)
        {
            List<User> listUsers = ReadAll();
            int status = 1;
            foreach (var item in listUsers)
            {
                if ((item.Email == email)  && (item.Password == password))
                {
                    status = 0;  
                }
            }
            return status;
        }

    }
}

