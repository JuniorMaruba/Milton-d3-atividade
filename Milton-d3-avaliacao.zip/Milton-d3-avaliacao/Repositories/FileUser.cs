﻿using System;
using System.Text;

namespace Milton_d3_avaliacao.Repositories
{
    public class FileUser
    {
        private const string path = "C:/Users/CTEDS_21/Desktop/Milton-d3-avaliacao/Milton-d3-avaliacao/Milton-d3-avaliacao.txt";
        private readonly FileStream _fileStream;

        public FileUser(FileStream fileStream)
        {
            CreateFolderFile(path);
            this._fileStream = fileStream;
        }


        public static void CreateFolderFile(string path)
        {
            string folder = path.Split("/")[0];

            if (!Directory.Exists(folder))
            {
                Directory.CreateDirectory(folder);
            }

            if (!File.Exists(path))
            {
                File.Create(path).Close();
            }
        }

        private static string PrepareLine(User user)
        {
            return $"O usuario {user.Name} acessou o sistema as {DateTimeOffset.Now}.";
        }

        public void RegisterAcess(User user)
        {
            string line = PrepareLine(user);
            byte[] info = new UTF8Encoding(true).GetBytes(line);
            _fileStream.Write(info);
        }

    }
}

