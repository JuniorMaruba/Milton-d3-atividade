﻿using System;
namespace Milton_d3_avaliacao.Interfaces
{
    internal interface IUser
    {
        List<User> ReadAll();

        int checkUser(string? email, string? password);


    }
}

