﻿using System;
namespace Milton_d3_avaliacao.Interfaces
{
    public interface IFileUser
    {
        void RegisterAcess(User user);
    }
}

