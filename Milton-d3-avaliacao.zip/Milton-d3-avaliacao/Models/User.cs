﻿using System;
namespace Milton_d3_avaliacao
{
    public class User
    {
        public string IdUser { get; set; } = string.Empty;

        public string Name { get; set; } = string.Empty;

        public string Email { get; set; } = string.Empty;

        public string Password { get; set; } = string.Empty;
    }
}

