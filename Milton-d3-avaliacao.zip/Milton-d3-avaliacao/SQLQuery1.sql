
-- Define qual banco de dados ser� utilizado
USE db_21;
GO

-- Cria a tabela User
CREATE TABLE [User](
	IdUser		    VARCHAR(255) NOT NULL UNIQUE,
	[Name]		    VARCHAR(255) NOT NULL,
	Email		    TEXT NOT NULL,
	[Password]	    VARCHAR(255) NOT NULL
);
GO

-- Lista os dados da tabela
SELECT * FROM [User];
GO

-- Insere um registro na tabela
INSERT INTO [User] (IdUser, [Name], Email, [Password])
VALUES				 ('ffbf60b6-8665-4983-9c56-f30130eed5bd', 'Usuario_Padrao', 'admin@email.com', 'admin123');
GO

