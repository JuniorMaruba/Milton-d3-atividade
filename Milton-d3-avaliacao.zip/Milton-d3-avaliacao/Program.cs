﻿using Milton_d3_avaliacao.Repositories;
using Milton_d3_avaliacao.Interfaces;

namespace Milton_d3_avaliacao
{
    public class Program
    {
        private const string path = "C:/Users/CTEDS_21/Desktop/Milton-d3-avaliacao/Milton-d3-avaliacao/Milton-d3-avaliacao.txt";

        public static void Main(string[] args)
        {
            FileStream file = File.OpenWrite(path);

            FileUser fileUser = new(file);

            RepositoryUser user = new();
            string? opcao = "0";
            do
            {
                Console.WriteLine("-----------------------------------------------------");
                Console.WriteLine("Bem Vindo ao programa do CTEDS-D3!\n");
                Console.WriteLine("Caso voce queira fazer algo, basta clicar em duas opcoes:\n");
                Console.WriteLine("0 - Acessar");
                Console.WriteLine("1 - Cancelar\n");
                Console.WriteLine("Opcao: ");
                opcao = Console.ReadLine();

                if (opcao == "0")
                {
                    Console.WriteLine("\n-----------------------------------------------------");
                    Console.WriteLine("\nAgora, falta voce logar no nosso sistema!\n");
                    Console.WriteLine("Por favor, coloque o login e a senha do usuario!\n");
                    Console.WriteLine("Login: ");
                    string? login = Console.ReadLine();
                    Console.WriteLine("\nSenha: ");
                    string? password = Console.ReadLine();
                    if (user.checkUser(login, password) == 0)
                    {
                        fileUser.RegisterAcess(user.findUser(login));
                        Console.WriteLine("\n-----------------------------------------------------");
                        Console.WriteLine("Bem vindo ao sistema CTEDS! Escolha a opcao que voce desejar:\n ");
                        Console.WriteLine("0 - Deslogar");
                        Console.WriteLine("1 - Encerrar o sistema\n");
                        Console.WriteLine("Opcao: ");
                        string? opcao2 = Console.ReadLine();
                        if (opcao2 == "1")
                        {
                            opcao = "1";
                        }
                    }
                    else
                    {
                        Console.WriteLine("\nUsuário não encontrado no nosso banco de dados!");
                    }

                }
            } while (opcao == "0");
        }
    }
}